jupyter 

pip install jupyter

jupyter

편집중(초록색)

>  shift enter(실행 후 + 다음셀 생성)
>
> ctrl enter(지금 셀만 실행)
>
> alt enter(무조건 실행 후 다음셀)

command 모드 (파랑색) h : 도움말

> d,d : delete selected cells
>
> a : insert cell above
>
> b : insert cell below
>
> enter / esc : edit mode / command mode
>
> [숫자] => 실행된 순서
>
> 모든 셀은 서로 관여를 함 > 변수가 동일하면 순서에 따라 값이 바뀜
>
> [*] => kernel -> Restart & Clear Output : 아예 처음으로 돌아감
>
> command 모드에서 m 누르면 마크다운 모드





