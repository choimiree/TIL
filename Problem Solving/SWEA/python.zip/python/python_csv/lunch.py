import csv

lunch = {
    '양자강' : '02-111-2222',
    '김밥까페' : '02-333-4444',
    '순남시레기' : '02-555-6666'
}

# 파일을 열어야 함.
# open 내장함수로 해당 파일을 열고 파일 객체를 만든다.

with open('lunch.csv', 'w', newline = '', encoding='utf-8') as csvfile:
# print(csvfile)

    csv_writer = csv.writer(csvfile)
    # print(csv_writer)
    for item, number in lunch.items():
        csv_writer.writerow([item, number])

#파일 조작이 끝나면 반드시 닫아야 한다. (with 문은 필요없음)
