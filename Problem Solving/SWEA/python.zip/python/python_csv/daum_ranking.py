import requests
import csv
from pprint import pprint
from bs4 import BeautifulSoup

daum_url = 'https://www.daum.net'
response = requests.get(daum_url).text
data = BeautifulSoup(response, 'html.parser')
# print(data)
rankings = data.select('#mArticle > div.cmain_tmp > div.section_media > div.hotissue_builtin > div.realtime_part > ol > li > div > div:nth-child(1) > span.txt_issue > a') #여러개 가져올때(리스트)
# li의 1st child의 div의 1st child만 들고오면 제일 첫 검색순위를 따온거.
# 전체 순위를 다 들고오고 싶으면 li 전체를 들고오면 된다, nth-child를 들고오면 안된다. 
# li로 남기고 나면 하나하나가 다 요소가 됨.
# 그래서 print하려면 for문 돌려야함

# pprint(rankings)
# 이 경로로 얻은 애가 랭킹임
# print(rankings)
# rankings = data.select_one('#mArticle > div.cmain_tmp > div.section_media > div.hotissue_builtin > div.realtime_part > ol > li:nth-child(1) > div > div:nth-child(1) > span.txt_issue > a').text

for idx, rank in enumerate(rankings, 1):
    print(f'{idx}위 : {rank.text}')

# data를 딕셔너리로 바꾸기
# result_dict = {}
# for idx, rank in enumerate(rankings, 1):
#     result_dict[f'{idx}위'] = rank.text
# pprint(result_dict)

# 위에서 만든 데이터로 csv에 저장
# with open('daum_rank.csv', 'w', newline='', encoding='utf-8') as csvfile:
#     csv_writer = csv.writer(csvfile)
#     for item, rank in result_dict.items():
#         csv_writer.writerow([item, rank])

# ^^^^ json으로 쓰려면 { key1 : 1위, key2 : 부산의료원 } 이렇게 되야함..! 
# 그래서 json데이터 처럼 데이터를 다시 만들어야함
result_list = []
for idx, rank in enumerate(rankings, 1):
    result_dict = {'rank':f'{idx}위', 'ranker':rank.text}
    result_list.append(result_dict)
# pprint(result_list)
# 새로 만든 데이터를 바탕으로 DictWriter를 사용하기
with open('daum_rank.csv', 'w', newline='', encoding='utf-8') as csvfile:
    # 저장할 데이터들의 필드 이름을 미리 지정(딕셔너리의 key이름과 일치해야 함)
    fieldnames = ['rank', 'ranker']
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    # 필드 이름을 csv 파일 최상단에 작성
    csv_writer.writeheader()
    # 리스트를 순회하면 key(csv의 필드)를 통해 value(내용) 작성
    for item in result_list:
        csv_writer.writerow(item) 
        # 공식 문서에 행에 딕셔너리가 하나씩 들어가게 된다. 
        # 우리가 만든 리스트의 요소들이 다 각각의 딕셔너리이므로 바로 item넣어주면 된다.
    
