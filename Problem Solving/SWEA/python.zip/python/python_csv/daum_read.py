import csv

with open('daum_rank.csv', 'r', encoding='utf-8', newline='') as csvfile:
    # print(csvfile)
    fieldnames = ('rank', 'ranker')
    csv_reader = csv.DictReader(csvfile) # fieldname read인 경우에는 생략 가능함 (python cvs 공식 문서 참고)
    # print(csv_reader)
    for row in csv_reader:
        # print(row) # 딕셔너리를 뽑아오는 것과 동일한것
        print(row['rank'], row['ranker'])