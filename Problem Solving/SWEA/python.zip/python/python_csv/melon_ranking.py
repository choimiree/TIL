import requests
import csv
from pprint import pprint
from bs4 import BeautifulSoup
melon_url = 'https://www.melon.com/chart/index.htm'
headers = {
    'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36'
    }

# response 406 error
# 신원 밝혀야함
# F12 -> Network -> Headers-> User-Agent, 형식은 위와 아래처럼 맞춰줘야함
response = requests.get(melon_url, headers= headers).text
data = BeautifulSoup(response, 'html.parser')

# print(response)

# 1. 순위, 가수, 노래제목 뽑아서 프린트 성공
# 순위, 가수, 노래제목을 포함하는 요소를 먼저 크게 선택 후
# 그 안에서 반복을 돌면서 순위, 가수, 노래제목을 하나만 다시 선택   

songs = data.select('#lst50') # 큰 클래스 하나 잡고 (전체 리스트)
result_list = []
for song in songs:
    rank = song.select_one('td:nth-child(2) > div > span.rank').text # 안에서 순위 셀랙터 들고온다.
    title = song.select_one('td:nth-child(6) > div > div > div.ellipsis.rank01 > span > a').text
    artists = song.select_one('td:nth-child(6) > div > div > div.ellipsis.rank02 > a').text
    # 2. 데이터 가공(json처럼 데이터 만들기) -> 딕셔너리 모양 : 영진위 처럼
    item = {'rank': rank, 'title': title, 'artist': artists}
    # item = {'rank': rank, 'title': title, 'artist': [artist.text for artist in artists]}
    result_list.append(item)


# 3. 2번에서 만든 데이터로 csv 작성
with open('melon_ranking.csv', 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['rank', 'title', 'artist']
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    csv_writer.writeheader()

    for item in result_list:
        csv_writer.writerow(item)

# rankings = data.select('#lst50 > td > div > div > div.ellipsis.rank01 > span > a')
# singers = data.select('#lst50 > td:nth-child(6) > div > div > div.ellipsis.rank02 > a:nth-child(1)')
# # pprint(rankings)
# # pprint(singer)

# # 1. 순위, 가수, 노래제목 뽑아서 프린트 성공
# # 2. 데이터 가공(json처럼 데이터 만들기) -> 딕셔너리 모양 : 영진위 처럼
# # 3. 2번에서 만든 데이터로 csv 작성

# result_list = []
# for idx, song, singer in zip(range(1,51), rankings, singers):
#      result_dict = {'rank':f'{idx}위', 'song':song.text, 'singer':singer.text}
#      result_list.append(result_dict)

# with open('melon_ranking.csv', 'w', newline='', encoding='utf-8') as csvfile:
#     fieldnames = ['rank', 'song', 'singer']
#     csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
#     csv_writer.writeheader()

#     for item in result_list:
#         csv_writer.writerow(item)
