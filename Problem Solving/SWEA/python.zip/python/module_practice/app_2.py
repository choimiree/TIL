from flask import Flask
import app

app = Flask(__name__)