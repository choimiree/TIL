pi = 3.14

def my_max(a, b):
    if a > b:
        print(f'{a}가 더 큽니다') 
    else:
        print(f'{b}가 더 큽니다')