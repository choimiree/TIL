### git (분산버전프로그램)

**working directory** --(add)--> **index(staging area)** --(commit)--> **쌓인 커밋들(HAED)** --(push)--> GitHub



#### git 기본

- git add helloworld.py
- git commit -m (-로 시작하면 보통 shortname)
- git config --global user.name("John") (--로 시작하면 longname)



#### Git Bash 명령어

> pwd : 경로 알수 있음 (working directory - home)
>
> ls :  리스트(현재 working directory 와 파일 이름 다 볼 수 있음)
>
> clear : 위쪽의 목록이 사라지고 상단으로 올라감 (= ctrl + l)
>
> **touch** a. txt : 파일 만들기(현재 위치에 만들어짐)
>
> **mkdir** test: 폴더 만들기
>
> **rm** a. txt :  파일 지우기(remove)
>
> **rm -r test** : 폴더 지우기 
>
> **cd /** : 최하단으로 간다(root)
>
> **cd ~** : home directory로 간다
>
> **cd videos/** : vidoes 폴더로 들어감
>
> **cd ..** : 상위 폴더로 뒤로 가기
>
> **cd -** : 바로 직전의 **상황**



#### git 정보 넣기 

git config --global user.name kyngskwk(이름 설정)

git config --global user.email kyngskwk@gmail.com(이메일 설정)

git config --global --list (설정한 리스트 보기)

git  init (master) : git의 관리를 받고 있는 중(해당 폴더만 가능)

*관리할 폴더 최상단에만 git init을 지정*

*숨긴 파일이나 숨긴 폴더는 이름앞에 . 이 되서 보임, 정보들이 .git안에 들어가게됨*

**git status : 상태확인 늘 해야함**

git add a.py : git 에 올리는것

**git commit -m "first commit"** 첫번째 커밋

git status -> working tree clean

**git log** : 커밋의 해시값을 찾아 돌아감 (우리는 first commit)

커밋까지 한 것이 한 사이클임



>  파일을 수정하고나서 git status를 쳐보면 변경사항이 있다고 빨갛게 이름이 뜸. 
>
> -> git add -> git status -> 이름이 초록색으로 바뀌면 커밋할 준비가 되어있다. -> git commit -m "second commit" -> git status -> 아무것도 없으면 정상  -> git log 



```
git remote add origin https://github.com/kyngskwk/routine.git
git push -u origin master
```

#### **git hub : git의 원격저장소**





git init

git add.

git commit -m "commit message"

git remote -v : remote된 주소 확인

git push -u origin master



1. 반드시 commit 이후에 매번 push 할 필요는 없다.

2. **`git push -u origin master` 이후에  `push`는 명령어가 그냥 `git push`라고 해도 된다.** 

   단, git push origin master 을 한 이후에는 계속 그 명령어를 써야함

   **git pull**

*****자리를 옮기면 전 사람의 github인증서를 지워야한다.*****



git clone + git hub 주소  => 폴더랑 파일이 다 같이 온다. 

클론 이후는 init 을 하지 않아도 된다.





ssafy --(push)--> github --(clone)--> 집

집--(push)--> github --(pull)--> ssafy



숨긴 항목 .git 을 삭제하면된다.